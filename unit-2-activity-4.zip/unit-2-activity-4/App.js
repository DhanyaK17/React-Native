import React, { useEffect, useRef, useState } from "react";
import {
  View,
  Text,
  Image,
  TextInput,
  Pressable,
  ScrollView,
  StyleSheet,
  Button,
  Switch,
  FlatList,
  SectionList,
  Alert,
  Animated,
  Dimensions,
  ActivityIndicator,
  KeyboardAvoidingView,
  Linking,
  Modal,
  StatusBar,
  Platform,
} from "react-native";

const { width, height } = Dimensions.get("window");

export default function App() {
  const [name, setName] = useState("");
  const [darkMode, setDarkMode] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [loading, setLoading] = useState(false);

  // Animated component
  const animation = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(animation, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(animation, {
          toValue: 0,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, []);

  const scale = animation.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 1.2],
  });

  // FlatList data
  const products = [
    { id: "1", name: "Laptop", price: "₹50,000" },
    { id: "2", name: "Mobile Phone", price: "₹25,000" },
    { id: "3", name: "Headphones", price: "₹2,500" },
    { id: "4", name: "Smart Watch", price: "₹5,000" },
  ];

  // SectionList data
  const sections = [
    {
      title: "Electronics",
      data: ["Laptop", "Mobile Phone", "Headphones"],
    },
    {
      title: "Accessories",
      data: ["Keyboard", "Mouse", "USB Cable"],
    },
  ];

  // Button action
  const showAlert = () => {
    Alert.alert(
      "Welcome!",
      name
        ? `Hello ${name}! Welcome to React Native.`
        : "Please enter your name."
    );
  };

  // ActivityIndicator demo
  const startLoading = () => {
    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      Alert.alert("Completed", "Loading finished!");
    }, 2000);
  };

  // Linking demo
  const openWebsite = () => {
    Linking.openURL("https://reactnative.dev");
  };

  return (
    <View
      style={[
        styles.container,
        darkMode && styles.darkContainer,
      ]}
    >
      {/* StatusBar */}
      <StatusBar
        barStyle={darkMode ? "light-content" : "dark-content"}
        backgroundColor={darkMode ? "#121212" : "#ffffff"}
      />

      {/* ScrollView */}
      <ScrollView
        contentContainerStyle={styles.scrollContainer}
        keyboardShouldPersistTaps="handled"
      >
        {/* Text + View */}
        <View style={styles.header}>
          <Text style={styles.title}>
            React Native Core Components
          </Text>

          <Text style={styles.subtitle}>
            Learn and explore React Native components
          </Text>
        </View>

        {/* Image */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>1. Image</Text>

          <Image
            source={{
              uri: "https://reactnative.dev/img/tiny_logo.png",
            }}
            style={styles.image}
          />

          <Text style={styles.description}>
            This image is rendered using the Image component.
          </Text>
        </View>

        {/* TextInput + KeyboardAvoidingView */}
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : undefined}
        >
          <View style={styles.card}>
            <Text style={styles.cardTitle}>
              2. TextInput
            </Text>

            <TextInput
              style={styles.input}
              placeholder="Enter your name"
              value={name}
              onChangeText={setName}
            />

            <Text style={styles.inputResult}>
              Hello, {name || "Guest"}!
            </Text>
          </View>
        </KeyboardAvoidingView>

        {/* Pressable */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>
            3. Pressable
          </Text>

          <Pressable
            style={({ pressed }) => [
              styles.pressable,
              pressed && styles.pressed,
            ]}
            onPress={() =>
              Alert.alert("Pressable", "You pressed the button!")
            }
          >
            <Text style={styles.pressableText}>
              Press Me
            </Text>
          </Pressable>
        </View>

        {/* Button + Alert */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>
            4. Button & Alert
          </Text>

          <Button
            title="Show Alert"
            onPress={showAlert}
          />
        </View>

        {/* Switch */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>
            5. Switch
          </Text>

          <View style={styles.switchRow}>
            <Text style={styles.description}>
              Dark Mode
            </Text>

            <Switch
              value={darkMode}
              onValueChange={setDarkMode}
            />
          </View>
        </View>

        {/* Animated */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>
            6. Animated
          </Text>

          <Animated.View
            style={[
              styles.animatedBox,
              {
                transform: [{ scale }],
              },
            ]}
          >
            <Text style={styles.animatedText}>
              Animated
            </Text>
          </Animated.View>
        </View>

        {/* Dimensions */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>
            7. Dimensions
          </Text>

          <Text style={styles.description}>
            Screen Width: {width.toFixed(0)} px
          </Text>

          <Text style={styles.description}>
            Screen Height: {height.toFixed(0)} px
          </Text>
        </View>

        {/* ActivityIndicator */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>
            8. ActivityIndicator
          </Text>

          {loading ? (
            <ActivityIndicator
              size="large"
              color="#4F46E5"
            />
          ) : (
            <Button
              title="Start Loading"
              onPress={startLoading}
            />
          )}
        </View>

        {/* FlatList */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>
            9. FlatList
          </Text>

          <FlatList
            data={products}
            scrollEnabled={false}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.listItem}>
                <Text style={styles.itemName}>
                  {item.name}
                </Text>

                <Text style={styles.price}>
                  {item.price}
                </Text>
              </View>
            )}
          />
        </View>

        {/* SectionList */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>
            10. SectionList
          </Text>

          <SectionList
            sections={sections}
            scrollEnabled={false}
            keyExtractor={(item, index) =>
              item + index
            }
            renderSectionHeader={({ section }) => (
              <Text style={styles.sectionHeader}>
                {section.title}
              </Text>
            )}
            renderItem={({ item }) => (
              <Text style={styles.sectionItem}>
                • {item}
              </Text>
            )}
          />
        </View>

        {/* Modal */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>
            11. Modal
          </Text>

          <Button
            title="Open Modal"
            onPress={() => setModalVisible(true)}
          />
        </View>

        {/* Modal UI */}
        <Modal
          visible={modalVisible}
          transparent={true}
          animationType="slide"
          onRequestClose={() => setModalVisible(false)}
        >
          <View style={styles.modalBackground}>
            <View style={styles.modalBox}>
              <Text style={styles.modalTitle}>
                React Native Modal
              </Text>

              <Text style={styles.description}>
                This is a modal window created using
                the Modal component.
              </Text>

              <Button
                title="Close Modal"
                onPress={() => setModalVisible(false)}
              />
            </View>
          </View>
        </Modal>

        {/* Linking */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>
            12. Linking
          </Text>

          <Button
            title="Open React Native Website"
            onPress={openWebsite}
          />
        </View>

        {/* StyleSheet */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>
            13. StyleSheet
          </Text>

          <Text style={styles.description}>
            All application styles are organized using
            React Native StyleSheet.
          </Text>
        </View>

        {/* Final section */}
        <View style={styles.footer}>
          <Text style={styles.footerTitle}>
            React Native Components Demo
          </Text>

          <Text style={styles.footerText}>
            View • Text • Image • TextInput • Pressable
            • ScrollView • StyleSheet • Button • Switch
            • FlatList • SectionList • Alert • Animated
            • Dimensions • ActivityIndicator
            • KeyboardAvoidingView • Linking • Modal
            • StatusBar
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

// StyleSheet
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F5F7FB",
  },

  darkContainer: {
    backgroundColor: "#121212",
  },

  scrollContainer: {
    padding: 20,
    paddingTop: 50,
    paddingBottom: 40,
  },

  header: {
    alignItems: "center",
    marginBottom: 25,
  },

  title: {
    fontSize: 28,
    fontWeight: "bold",
    textAlign: "center",
    color: "#4F46E5",
  },

  subtitle: {
    fontSize: 15,
    color: "#666",
    textAlign: "center",
    marginTop: 8,
  },

  card: {
    backgroundColor: "#FFFFFF",
    borderRadius: 15,
    padding: 18,
    marginBottom: 18,

    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 5,

    elevation: 3,
  },

  cardTitle: {
    fontSize: 19,
    fontWeight: "bold",
    marginBottom: 15,
    color: "#222",
  },

  description: {
    fontSize: 14,
    color: "#555",
    lineHeight: 22,
  },

  image: {
    width: 100,
    height: 100,
    alignSelf: "center",
    marginBottom: 10,
  },

  input: {
    height: 50,
    borderWidth: 1,
    borderColor: "#CCC",
    borderRadius: 10,
    paddingHorizontal: 15,
    fontSize: 16,
    backgroundColor: "#FAFAFA",
  },

  inputResult: {
    marginTop: 12,
    fontSize: 16,
    fontWeight: "600",
  },

  pressable: {
    backgroundColor: "#4F46E5",
    padding: 15,
    borderRadius: 10,
    alignItems: "center",
  },

  pressed: {
    opacity: 0.6,
  },

  pressableText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "bold",
  },

  switchRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  animatedBox: {
    width: 100,
    height: 100,
    borderRadius: 20,
    backgroundColor: "#4F46E5",
    alignSelf: "center",
    justifyContent: "center",
    alignItems: "center",
  },

  animatedText: {
    color: "#FFF",
    fontWeight: "bold",
  },

  listItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#EEE",
  },

  itemName: {
    fontSize: 16,
    fontWeight: "500",
  },

  price: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#4F46E5",
  },

  sectionHeader: {
    fontSize: 17,
    fontWeight: "bold",
    backgroundColor: "#EDE9FE",
    padding: 10,
    marginTop: 5,
  },

  sectionItem: {
    fontSize: 15,
    padding: 8,
  },

  modalBackground: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    alignItems: "center",
  },

  modalBox: {
    width: "85%",
    backgroundColor: "#FFF",
    padding: 25,
    borderRadius: 20,
  },

  modalTitle: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 15,
    textAlign: "center",
  },

  footer: {
    padding: 20,
    alignItems: "center",
  },

  footerTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#4F46E5",
    marginBottom: 10,
  },

  footerText: {
    textAlign: "center",
    color: "#666",
    lineHeight: 22,
  },
});
