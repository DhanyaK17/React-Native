import React from 'react';
import {
  View,
  Button,
  Text,
  StyleSheet,
  Switch,
} from 'react-native';
let id = 0;
const styles = StyleSheet.create({
  todoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  appContainer: {
    paddingTop: 10,
  },
});
const Todo = props => (
  <View style={[styles.todoContainer, styles.fill]}>
    <Switch
      value={props.todo.checked}
      onValueChange={props.onToggle}
    />
    <Text>
      {props.todo.text}
    </Text>

    <Button
      title="Delete"
      onPress={props.onDelete}
    />
  </View>
);
export default class App extends React.Component {
  constructor() {
    super();

    this.state = {
      todos: [],
    };
  }
  addTodo() {
    id++;
    const text = `TODO number ${id}`;
    this.setState({
      todos: [
        ...this.state.todos,
        {
          id: id,
          text: text,
          checked: false,
        },
      ],
    });
  }
  removeTodo(id) {
   this.setState({
      todos: this.state.todos.filter(todo => todo.id !== id),
    });
  }
  toggleTodo(id) {
    this.setState({
      todos: this.state.todos.map(todo => {
        if (todo.id !== id) return todo;
        return {
          id: todo.id,
          text: todo.text,
          checked: !todo.checked,
        };
      }),
    });
  }
  render() {
    return (
      <View style={[styles.appContainer, styles.fill]}>
        <Text>
          Todo count: {this.state.todos.length}
        </Text>
        <Text>
          Unchecked todo count:{' '}
          {this.state.todos.filter(todo => !todo.checked).length}
        </Text>
        <Button
          onPress={() => this.addTodo()}
          title="Add TODO"      />
{this.state.todos.map(todo => (
          <Todo
            key={todo.id}
            onToggle={() => this.toggleTodo(todo.id)}
            onDelete={() => this.removeTodo(todo.id)}
            todo={todo}
          />
        ))}
      </View>
    );
  }
}
