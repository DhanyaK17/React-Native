import React from 'react';
import { Text } from 'react-native';
const Cat = () => {
 const name = "Dhanya";
 return (
 <Text>Hello, I am {name}!</Text>
 );
}
export default Cat;

// -----------------------------------------------------------------
// import React from 'react';
// import { Text } from 'react-native';
// const getFullName = (firstName, secondName, thirdName) => {
//  return firstName + " " + secondName + " " + thirdName;
// }
// const Cat = () => {
//  return (
//  <Text>
//  Hello, I am {getFullName("Rum", "Tum", "Tugger")}!
//  </Text>
//  );
// }
// export default Cat;

// --------------------------------------------------------------
// import React from 'react';
// import { Text, TextInput, View } from 'react-native';
// const Cat = () => {
//  return (
//  <View>
//  <Text>Hello, I am...</Text>
//  <TextInput
//  style={{
//  height: 40,
//  borderColor: 'gray',
//  borderWidth: 1
//  }}
//  defaultValue="Name me!"
//  />
//  </View>
//  );
// }
// export default Cat;

// --------------------------------------------------------------
// import React from 'react';
// import { Text, TextInput, View } from 'react-native';
// const Cat = () => {
//  return (
//  <View>
//  <Text>I am also a cat!</Text>
//  </View>
//  );
// }
// const Cafe = () => {
//  return (
//  <View>
//  <Text>Welcome!</Text>
//  <Cat />
//  <Cat />
//  <Cat />
//  </View>
//  );
// }
// export default Cafe;

// --------------------------------------------------------------