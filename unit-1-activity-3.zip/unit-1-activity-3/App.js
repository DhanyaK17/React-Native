// import React from 'react';
// import { Text, View } from 'react-native';
// const Cat = (props) => {
//  return (
//  <View>
//  <Text>Hello, I am {props.name}!</Text>
//  </View>
//  );
// }
// const Cafe = () => {
//  return (
//  <View>
//  <Cat name="Maru" />
//  <Cat name="Jellylorum" />
//  <Cat name="Spot" />
//  </View>
//  );
// }
// export default Cafe;

// --------------------------------------------------------
import React from 'react';
import { Text, View, Image } from 'react-native';
const CatApp = () => {
 return (
 <View>
 <Image
 source={{uri: "https://reactnative.dev/docs/assets/p_cat1.png"}}
 style={{width: 200, height: 200}}
 />
 <Text>Hello, I am your cat!</Text>
 </View>
 );
}
export default CatApp;