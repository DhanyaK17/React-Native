import React, { Component } from 'react';
import { AppRegistry, FlatList, StyleSheet, Text,View,Alert } from 'react-native';

 const Data = [{key: 'HTML'},{key: 'CSS'}, {key: 'Java Script'},{key: 'React JS'},  
                        {key: 'Node JS'},{key: 'Express JS'},{key: 'Mongo DB'},  
                        {key: 'React Native'}   
                    ];
class App extends Component {
renderSeparator = () => {  
        return (  
            <View  style={{ height: 1,  
                    width: "100%",  
                    backgroundColor: "#000",  
                }}  
            />  
        );  
    };  
    //handling onPress action  
    getListViewItem = (item) => {  
        Alert.alert(item.key);  
    }  
  render() {
    return (
        <View style={styles.container}> 
        <Text>Hello, I am your Dhanya!</Text>
        <FlatList  
                    data={Data}
                    
              
                    renderItem={({item}) =>  
                        <Text style={styles.item}  
                              onPress={() => this.getListViewItem(item)}>{item.key}</Text>}  
                    ItemSeparatorComponent={this.renderSeparator}  
                />  
       </View>
    );
  }
}
const styles = StyleSheet.create({  
    container: {  
        flex: 1,  
    },  
    item: {  
        padding: 10,  
        fontSize: 18,  
        height: 44,  
    },  
})  
export default App;
