import React from 'react';

import {
  View,
  Text,
  SectionList,
  StyleSheet,
  Button,
} from 'react-native';

import AddContactForm from './AddContactForm';

class App extends React.Component {

  state = {
    showForm: false,
    showContacts: true,

    contacts: [
      {
        name: 'Arun Kumar',
        phone: '9876543210',
      },
      {
        name: 'Priya Devi',
        phone: '9123456780',
      },
      {
        name: 'Ravi Kumar',
        phone: '9988776655',
      },
    ],
  };

  // Add new contact
  addContact = newContact => {
    this.setState(prevState => ({
      showForm: false,

      contacts: [
        ...prevState.contacts,
        {
          name: newContact.name,
          phone: newContact.phone,
        },
      ],
    }));
  };

  // Show / Hide contacts
  toggleContacts = () => {
    this.setState(prevState => ({
      showContacts: !prevState.showContacts,
    }));
  };

  // Create sections based on first letter
  createSections = contacts => {

    const groupedContacts = {};

    contacts.forEach(contact => {

      const firstLetter =
        contact.name.charAt(0).toUpperCase();

      if (!groupedContacts[firstLetter]) {
        groupedContacts[firstLetter] = [];
      }

      groupedContacts[firstLetter].push(contact);
    });

    return Object.keys(groupedContacts)
      .sort()
      .map(letter => ({
        title: letter,
        data: groupedContacts[letter],
      }));
  };

  render() {

    const {
      showForm,
      showContacts,
      contacts,
    } = this.state;

    const sections = this.createSections(contacts);

    return (
      <View style={styles.container}>

        {/* Header */}
        <Text style={styles.header}>
          Contacts App
        </Text>

        {/* Toggle Contact Button */}
        <View style={styles.toggleButton}>
          <Button
            title="Toggle Contact"
            onPress={this.toggleContacts}
          />
        </View>

        {/* Add Contact Button */}
        {!showForm && (
          <View style={styles.addButton}>
            <Button
              title="Add Contact"
              onPress={() =>
                this.setState({
                  showForm: true,
                })
              }
            />
          </View>
        )}

        {/* Add Contact Form */}
        {showForm && (
          <AddContactForm
            onSubmit={this.addContact}
          />
        )}

        {/* Contacts */}
        {showContacts && (
          <SectionList
            sections={sections}

            keyExtractor={(item, index) =>
              item.phone + index
            }

            renderSectionHeader={({
              section: { title },
            }) => (
              <View style={styles.sectionHeader}>

                <Text style={styles.sectionHeaderText}>
                  {title}
                </Text>

              </View>
            )}

            renderItem={({ item }) => (
              <View style={styles.contactItem}>

                <Text style={styles.name}>
                  {item.name}
                </Text>

                <Text style={styles.phone}>
                  {item.phone}
                </Text>

              </View>
            )}
          />
        )}

      </View>
    );
  }
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },

  header: {
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    padding: 20,
    backgroundColor: '#2196F3',
    color: '#ffffff',
  },

  toggleButton: {
    padding: 10,
    backgroundColor: '#ffffff',
  },

  addButton: {
    padding: 10,
    backgroundColor: '#ffffff',
  },

  sectionHeader: {
    backgroundColor: '#dddddd',
    padding: 10,
    marginTop: 5,
  },

  sectionHeaderText: {
    fontSize: 20,
    fontWeight: 'bold',
  },

  contactItem: {
    backgroundColor: '#ffffff',
    padding: 15,
    marginHorizontal: 10,
    marginVertical: 4,
    borderRadius: 8,
  },

  name: {
    fontSize: 18,
    fontWeight: 'bold',
  },

  phone: {
    fontSize: 15,
    color: '#666666',
    marginTop: 5,
  },

});

export default App;