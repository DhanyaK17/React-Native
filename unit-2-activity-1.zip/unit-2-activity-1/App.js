import React, { Component } from 'react';
import { Text, View, StyleSheet, ScrollView } from 'react-native';
class ScrollViewExample extends Component {
  state = { leftNames: [
      { name: 'Ben', id: 1 },
      { name: 'Susan', id: 2 },
      { name: 'Robert', id: 3 },
      { name: 'Mary', id: 4 },
      { name: 'Daniel', id: 5 },
      { name: 'Laura', id: 6 },
       { name: 'John', id: 7 },
      { name: 'Debra', id: 8 },
      { name: 'Aron', id: 9 },
      { name: 'Ann', id: 10 },
      { name: 'Steve', id: 11 },
      { name: 'Olivia', id: 12 }
    ],
    rightNames: [
      { name: 'Ben', id: 1 },
      { name: 'Susan', id: 2 },
      { name: 'Robert', id: 3 },
      { name: 'Mary', id: 4 },
      { name: 'Daniel', id: 5 },
      { name: 'Laura', id: 6 },
      { name: 'John', id: 7 },
      { name: 'Debra', id: 8 },
      { name: 'Aron', id: 9 },
      { name: 'Ann', id: 10 },
      { name: 'Steve', id: 11 },
      { name: 'Olivia', id: 12 }
    ]
  };
  render() {
    return (
      <View style={styles.container}>
        {/* 6 / 6 Layout */}
        <View style={styles.mainContent}>
          {/* LEFT SIDE */}
          <View style={styles.leftSide}>
            <ScrollView>
              {this.state.leftNames.map((item) => (
                <View key={item.id} style={styles.item}>
                  <Text style={styles.itemText}>
                    {item.name}
                  </Text>
                </View>
              ))}
            </ScrollView>
          </View>
          {/* RIGHT SIDE */}
          <View style={styles.rightSide}>
            <ScrollView>
              {this.state.rightNames.map((item) => (
                <View key={item.id} style={styles.item}>
                  <Text style={styles.itemText}>
                    {item.name}
                  </Text>
                </View>
              ))}
            </ScrollView>
          </View>
        </View>
      </View>
    );
  }
}
export default ScrollViewExample;
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20
  },
  // Left + Right
  mainContent: {
    flex: 1,
    flexDirection: 'row'
  },
  // Left = 6
  leftSide: {
    flex: 6,
    borderColor: '#2a4944',
    padding: 10,
    marginRight: 5
  },
  // Right = 6
  rightSide: {
    flex: 6,
    borderColor: '#2a4944',
    padding: 10,
    marginLeft: 5
  },
  item: {
    padding: 15,
    marginBottom: 5,
    borderWidth: 1,
    borderColor: '#2a4944',
    backgroundColor: '#d2f7f1'
  },
  itemText: {
    fontSize: 16
  }
});
